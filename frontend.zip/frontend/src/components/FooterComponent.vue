<template>
    <footer class="text-center py-3 mt-4"
        style="background-color: var(--color-btn); border-top: 1px solid var(--color-border); color: var(--color-text-secondary)">
        <small>&copy; {{ new Date().getFullYear() }} BookHub</small>
    </footer>
</template>
